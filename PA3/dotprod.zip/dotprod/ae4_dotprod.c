float dotprod(float x[], float y[], int n)
{
    int i;
    float sum[n];
    for(i=0;i<n;i++){
        sum[i] = 0.0;
    }
    for(i = 0; i < n/4; i++)
    {
        sum[i*4] += x[i*4] * y[i*4];
        sum[i*4+1] += x[i*4+1] * y[i*4+1];
        sum[i*4+2] += x[i*4+2] * y[i*4+2];
        sum[i*4+3] += x[i*4+3] * y[i*4+3];
    }

    float res = 0.0;
    for(i=0;i<n/4;i++){
        res += (sum[i]+sum[i+1]+sum[i+2]+sum[i+3]);
    }

    return res;
}
