## Please run the below command to execute the Code

python3 PA1_pgajjala.py

I have used numpy as well, please make sure numpy is installed in your system.