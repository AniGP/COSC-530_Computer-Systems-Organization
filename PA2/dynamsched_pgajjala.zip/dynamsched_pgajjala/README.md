## Please run the below command to execute the Code

python3 PA2_pgajjala.py

I have used numpy, itertools and uuid as well, please make sure they are installed in your system.